# Final synchronized manuscript contribution — EnerghxPLUS DSS v2.0

All computational values below were generated directly from the frozen `app/engine.py` in this package.

## ABSTRACT — insert after the existing process-flow model sentence
A deterministic prescriptive decision-support layer was developed to convert feedstock, thermal and biogas resource states into constrained operating recommendations. The framework combines discrete feedstock logistics optimization, feedstock inventory and shortage management, reported HTC operating-state selection, and inventory-constrained biogas dispatch through the Enhanced Methane Capture Vessel (EMCV). Multi-period simulation represents biogas production, finite EMCV storage, terminal reserve requirements and competing HTC and electricity gas demands, providing an API-compatible operational layer for the EnerghxPLUS environment.

## INTRODUCTION — insert immediately before “Aim and Objectives”
Operational implementation of an integrated AD–HTC system requires more than process-state monitoring: it requires a mechanism that converts the current resource state into a feasible operating action. In the present system, the decision problem includes determining the required feedstock collection action, selecting an applicable HTC operating state, and dispatching a finite biogas resource between process heating and electricity utilization while preserving a required gas inventory. The present study therefore introduces a deterministic prescriptive decision-support framework coupling cattle-dung logistics, discrete HTC operating-state selection and multi-period biogas resource allocation through the physical storage state of the EMCV.

The principal computational contribution is an inventory-constrained decision architecture in which reported process parameters remain fixed while runtime resource states and operator priorities determine the recommended action. Unlike a sequential end-use allocation rule that redirects surplus gas after a predefined primary demand has been served, the formulation explicitly represents gas-production inflow, finite storage capacity, terminal reserve requirements, competing process demands and inventory carry-over between operating periods.

## AIM AND OBJECTIVES — add as final objective
Develop and computationally evaluate a deterministic prescriptive decision-support framework for feedstock logistics, HTC operating-state selection and inventory-constrained biogas dispatch, and implement the framework as an API-compatible layer for integration with EnerghxPLUS.

## METHODOLOGY — insert as a new subsection before Results and Discussion
### Deterministic Operational Decision-Support Framework
At decision interval t, the operational state is represented by feedstock demand and inventory, stored and incoming biogas, applicable HTC configuration, downstream gas demands and operator policy. The decision-support engine maps this state to a feedstock collection plan, HTC operating state, gas-dispatch action and next-period inventory.

For vehicle v:
M_delivered = Σ_v K_v n_v
M_available = I_f,t + M_delivered
M_short = max(0, M_required − M_available)
I_f,t+1 = max(0, M_available − M_required)

The logistics objective is:
C_L = Σ_v C_v n_v + H I_f,t+1 + R M_short

The manuscript-reported H = ₦150/kg-day and R = ₦7,500/kg are retained as fixed model parameters.

HTC operation is restricted to reported discrete states. The insulated state uses the reported 1.69 m³/h condition associated with 200°C after approximately 2.6 h. For a bare reactor requiring HTC-window attainment, the 3.00 m³/h reported state is selected. The 1.69 m³/h bare condition is retained only as a comparison state; the DSS does not interpolate unreported intermediate thermal behaviour.

### Inventory-Constrained Biogas Dispatch
Let I_t be EMCV inventory at the beginning of period t, P_t the incoming biogas during the period, and V_max the EMCV capacity:
G_t = I_t + P_t
O_t = max(0, G_t − V_max)
A_t = min(V_max, G_t)

The period gas balance is:
G_t = O_t + V_HTC,t + V_el,t + I_t+1

subject to:
0 ≤ I_t+1 ≤ V_max
I_t+1 ≥ R_min,t
0 ≤ V_HTC,t ≤ D_HTC,t
0 ≤ V_el,t ≤ D_el,t

The single-period feasibility boundary is:
A_t* = D_HTC,t + D_el,t + R_min,t

If A_t ≥ A_t*, both downstream demands can be met while preserving the minimum terminal reserve. If A_t < A_t*, the system is resource-constrained. Under HTC-priority operation, the minimum reserve is protected and usable gas is assigned to HTC before electricity. Electricity-priority reverses the two consuming applications. Balanced operation protects the reserve and distributes the remaining gas by equal proportional service of the two requested demands.

### Computational Evaluation
The frozen v2.0 engine was evaluated using 80 logistics stress-test cases, 432 single-period allocation cases and 72 period-level records from deterministic multi-period EMCV profiles. All reported computational outputs were generated from the same engine used by the API.

## RESULTS — insert after existing Inventory Holding Cost and Shortage Penalty subsection
### Prescriptive Logistics Results
With zero starting feedstock inventory, the cost model selected one motorized-tricycle trip for 450 kg, two motorized-tricycle trips for 900 kg and four motorized-tricycle trips for 1,800 kg. The 80 stress cases evaluated feedstock demand, initial inventory and transportation-time valuation using the manuscript-reported vehicle capacities, batch costs, holding cost and shortage penalty.

## RESULTS — insert immediately after the existing insulated/bare HTC comparison
### HTC Operating-State Decision
The reported increase from 1.69 to 3.00 m³/h corresponds to a 77.5% increase in gas-flow rate. The DSS uses the reported 1.69 m³/h insulated state for HTC target attainment and the reported 3.00 m³/h bare state when HTC-window attainment is required without insulation. The rule is discrete and does not infer reactor behaviour between reported operating points.

## RESULTS — insert after the HTC operating-state decision
### Inventory-Constrained Biogas Allocation
The single-period matrix contained 432 deterministic operating cases. 270 cases were resource-constrained and 162 cases satisfied all specified HTC, electricity and minimum-reserve requirements.

For an illustrative state with 2.0 m³ available, HTC demand of 1.5 m³, electricity demand of 1.5 m³ and a minimum terminal reserve of 0.5 m³, HTC-priority operation allocated 1.5 m³ to HTC, 0 m³ to electricity and retained 0.5 m³. Electricity-priority operation allocated 0 m³ to HTC, 1.5 m³ to electricity and retained 0.5 m³. Balanced operation allocated 0.75 m³ to each consuming application and retained 0.5 m³, providing 50% service of each 1.5 m³ demand.

The feasibility transition is A_t* = D_HTC,t + D_el,t + R_min,t. Below this boundary at least one requirement remains unmet; at or above it all requirements can be satisfied.

### Multi-Period EMCV State Transition
The horizon simulations represented production inflow, finite storage capacity, process dispatch and inventory carry-over. Across 72 period records, the maximum absolute numerical mass-balance residual was 1.11e-16 m³. The implemented scenarios therefore satisfy G_t = O_t + V_HTC,t + V_el,t + I_t+1 to numerical precision. The multi-period formulation extends one-shot sequential allocation by allowing the recommended action to change with stored-gas state and incoming production.

## ENERGHXPLUS API — replace the current future-tense API paragraph
The logistics, HTC operating-state and biogas-dispatch models were implemented as a deterministic prescriptive API for integration with the EnerghxPLUS simulation environment. Separate services expose logistics optimization, HTC state selection, single-period gas dispatch and multi-period EMCV simulation, while an integrated recommendation service combines the principal decision layers. Runtime inputs are maintained separately from manuscript-reported physical parameters, and returned recommendations include provenance identifying process-derived parameters and operator-defined decision inputs.

## DISCUSSION — insert near the end of Results and Discussion
The computational contribution extends the integrated AD–HTC–EMCV framework from process-state representation to prescriptive operation. Feedstock logistics determine how the required substrate reaches the facility; the HTC selector maps reported thermal states to applicable operating configurations; and the inventory-constrained allocator determines how stored and incoming biogas should be dispatched while respecting finite EMCV capacity and terminal reserve requirements. This stateful formulation differs from a purely sequential end-use distribution rule because gas not consumed remains part of the next-period system state.

## CONCLUSION — insert before the final concluding sentence
A deterministic prescriptive decision-support framework was developed in addition to the experimental and process-modeling components of the study. The final implementation couples feedstock logistics, reported HTC operating states and inventory-constrained biogas dispatch through the physical storage state of the EMCV. The computational results demonstrate distinct recommendations under HTC-priority, electricity-priority and balanced policies when gas is scarce, while the multi-period formulation preserves gas mass balance and storage-capacity constraints across successive operating periods. The API-compatible implementation provides a direct pathway from process-state information to traceable operational recommendations within EnerghxPLUS.

## Recommended novelty sentence
The principal computational contribution of this study is an inventory-constrained prescriptive decision-support framework that couples cattle-dung collection logistics with discrete HTC operating-state selection and multi-period biogas resource allocation through the physical storage state of the EMCV.
