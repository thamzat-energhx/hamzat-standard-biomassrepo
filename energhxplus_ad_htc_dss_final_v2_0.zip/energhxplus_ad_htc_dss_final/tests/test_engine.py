from app.engine import *
def test_logistics():
 assert optimize_logistics(450)["plan"]=={"tricycle":1}
 assert optimize_logistics(900)["plan"]=={"tricycle":2}
 assert optimize_logistics(1800)["plan"]=={"tricycle":4}
def test_htc():
 assert select_htc_state("insulated")["flow_m3_h"]==1.69
 assert select_htc_state("bare")["flow_m3_h"]==3.0
def test_priority_switch_and_reserve():
 h=allocate_single_period(2,1.5,1.5,.5,"htc_priority")
 e=allocate_single_period(2,1.5,1.5,.5,"electricity_priority")
 assert h["allocation_m3"]=={"htc":1.5,"electricity":0.0}
 assert e["allocation_m3"]=={"htc":0.0,"electricity":1.5}
 assert h["terminal_inventory_m3"]==.5 and e["terminal_inventory_m3"]==.5
def test_balanced():
 b=allocate_single_period(2,1.5,1.5,.5,"balanced")
 assert abs(b["allocation_m3"]["htc"]-.75)<1e-10
 assert abs(b["allocation_m3"]["electricity"]-.75)<1e-10
def test_horizon_mass_balance_capacity():
 r=simulate_horizon(.75,[.25,.25,.25],[.6,0,.6],[.4,.4,.4],[.2,.2,.2],1,"htc_priority")
 assert r["max_abs_mass_balance_error_m3"]<1e-10
 assert all(0<=p["end_inventory_m3"]<=1 for p in r["periods"])
def test_feasibility_boundary():
 assert allocate_single_period(3.5,1.5,1.5,.5,"balanced")["all_requirements_met"]
 assert not allocate_single_period(3.49,1.5,1.5,.5,"balanced")["all_requirements_met"]
